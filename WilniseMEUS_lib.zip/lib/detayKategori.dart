import 'package:flutter/material.dart';
import 'model/kategori_model.dart';
import 'payment.dart';
import 'style.dart';
import 'product.dart';
import 'api.dart';

class CategoryDetail extends StatelessWidget {
  final KategoriModel category;
  const CategoryDetail({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(category.title),
        actions: [
          TextButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const PayementPage()));
              },
              child: const Text(
                "PEYE",
                style: UtilsTheme.titleHead,
              ))
        ],
      ),
      body: SingleChildScrollView(
          child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Text(category.title, style: UtilsTheme.detailCategoryTitle),
          ),
          ProductListWidget(getProducts: () {
            return APIService.getProductsByCategory(category.title);
          }),
        ],
      )),
    );
  }
}
