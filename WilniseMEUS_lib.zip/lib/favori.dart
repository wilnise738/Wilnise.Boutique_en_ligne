import 'package:flutter/material.dart';
import 'stokaj.dart';
import 'package:provider/provider.dart';
import 'style.dart';
import 'product.dart';

class FavoritePage extends StatelessWidget {
  const FavoritePage({super.key});

  @override
  Widget build(BuildContext context) {
    StateNotifier state = context.watch<StateNotifier>();
    if (state.isLogin()) {
      return ProductListWidget(getProducts: () {
        return Storage.getListFavoriteProdcut(state.getUser()['id']);
      });
    } else {
      return ProductListWidget(
        getProducts: () {
          return Storage.getListFavoriteProdcut(-1);
        },
      );
    }
  }
}
