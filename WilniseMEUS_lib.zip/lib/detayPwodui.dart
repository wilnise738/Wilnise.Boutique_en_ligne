import 'package:flutter/material.dart';
import 'model/atik.dart';
import 'cartbutton.dart';
import 'package:provider/provider.dart';
import 'style.dart';

class ProductDetail extends StatelessWidget {
  final Article article;
  const ProductDetail({Key? key, required this.article}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final state = context.watch<StateNotifier>();
    return Scaffold(
      appBar: AppBar(title: Text(article.title)),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.network(
              article.image,
              fit: BoxFit.cover,
              width: double.infinity,
              height: 200,
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                children: [
                  const SizedBox(
                    height: 16,
                  ),
                  Text(
                    "Article ${article.category}",
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  Text(
                    article.description,
                    style: const TextStyle(
                      fontSize: 22,
                    ),
                  ),
                  const SizedBox(
                    height: 16,
                  ),
                  Text(
                    'Price: ${article.price}\$',
                    style: const TextStyle(
                      fontSize: 22,
                    ),
                  ),
                  
                  state.isLogin()
                      ? CartButtonWidget(
                          userId: state.getUser()['id'],
                          productId: article.id,
                        )
                      : CartButtonWidget(
                          userId: -1,
                          productId: article.id,
                        ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
