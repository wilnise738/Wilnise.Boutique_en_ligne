//Modelisation
class KategoriModel {
  final String title;
  

  KategoriModel({ required this.title });

  factory KategoriModel.fromJson(String jsonData) {
    return KategoriModel(

      title: jsonData,  
    );
  }
}
