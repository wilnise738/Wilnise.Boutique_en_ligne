import 'package:flutter/material.dart';

class PayementPage extends StatelessWidget {
  const PayementPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey,
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: const Text(
          'Payment',
          style: TextStyle(color: Colors.black),
        ),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Chwazi pa ki mwayen wap peye'),
            const SizedBox(height: 16),
            InkWell(
              onTap: () {
                // Traitement pour payer par PayPal
              },
              child: Image.asset(
                'cartebancaire.png',
                width: 150,
              ),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () {
                // Traitement pour payer par PayPal
              },
              child: Image.asset(
                'paypal.png',
                width: 150,
              ),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: () {
                // Traitement pour payer par PayPal
              },
              child: Image.asset(
                'moncach.png',
                width: 150,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
