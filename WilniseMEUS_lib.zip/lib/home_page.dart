import 'package:flutter/material.dart';
import 'api.dart';
import 'style.dart';
import 'dart:convert';
import 'productlist.dart';
import 'package:http/http.dart' as http;
import 'product.dart';
import 'category.dart';

class HomePageScreen extends StatefulWidget {
  const HomePageScreen({Key? key}) : super(key: key);

  @override
  State<HomePageScreen> createState() => _HomePageScreenState();
}

class _HomePageScreenState extends State<HomePageScreen> {
  List<dynamic> _products = [];
  List<dynamic> _categories = [];

  final String _host = 'https://fakestoreapi.com';

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    final productsResponse =
        await http.get(Uri.parse('$_host/products?sort=desc&limit=6'));
    final categoriesResponse = await http
        .get(Uri.parse('https://fakestoreapi.com/products/categories'));

    if (productsResponse.statusCode == 200 &&
        categoriesResponse.statusCode == 200) {
      setState(() {
        _products = json.decode(productsResponse.body);
        _categories = json.decode(categoriesResponse.body).take(4).toList();
      });
    } else {
      throw Exception('Impossible de recuperer les données');
    }
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Column(
      children: [
        Container(
          alignment: Alignment.centerLeft,
          margin: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
          child: const Text(
              "Les 6 Meilleurs Produits", //style: TextStyle(color: Colors.black)
              style: UtilsTheme.categoryTop),
        ),
        const ProductListWidget(getProducts: APIService.getTopProducts),
        Container(
          alignment: Alignment.centerLeft,
          margin: const EdgeInsets.symmetric(
            vertical: 10,
            horizontal: 10,
          ),
          child: const Text("Les 4 Meilleures Catégories",
              style: UtilsTheme.categoryTop),
        ),
        const CategoryListWidget(getCategories: APIService.getTopCategories),
        Center(
          child: ElevatedButton.icon(
            icon: const Icon(Icons.list, color: Colors.black),
            label: const Text(
              'Tous les produits',
              style: TextStyle(color: Colors.black),
            ),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const ProductListPage(),
                ),
              );
            },
            style: ButtonStyle(
              backgroundColor: MaterialStateProperty.all<Color>(Colors.white),
            ),
          ),
        ),
      ],
    ));
  }
}
