import 'package:flutter/material.dart';
import 'stokaj.dart';

class CartButtonWidget extends StatefulWidget {
  final int userId;
  final int productId;

  const CartButtonWidget(
      {Key? key, required this.userId, required this.productId})
      : super(key: key);

  @override
  State<CartButtonWidget> createState() => _CartButtonWidgetState();
}

class _CartButtonWidgetState extends State<CartButtonWidget> {
  late Future<bool> isCart;

  @override
  void initState() {
    super.initState();
    isCart = Storage.isCartInProduct(widget.userId, widget.productId);
  }

  @override
  Widget build(BuildContext context) {
    const double iconSize = 30;
    return Align(
      alignment: Alignment.bottomRight,
      child: FutureBuilder(
        future: isCart,
        builder: (context, snapshot) {
          if (snapshot.hasData) {
            return FloatingActionButton(
              onPressed: () async {
                if (widget.userId != -1) {
                  await Storage.toggleCartsProduct(
                      widget.userId, widget.productId);
                  setState(() {
                    isCart = Storage.isCartInProduct(
                        widget.userId, widget.productId);
                  });
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("You must be connected to add to cart"),
                    ),
                  );
                }
              },
              backgroundColor: Colors.blue,
              child: snapshot.data!
                  ? const Icon(
                      Icons.shopping_cart,
                      size: iconSize,
                    )
                  : const Icon(
                      Icons.shopping_cart_outlined,
                      size: iconSize,
                    ),
            );
          } else if (snapshot.hasError) {
            return Text("${snapshot.error}");
          } else {
            return const CircularProgressIndicator();
          }
        },
      ),
    );
  }
}
